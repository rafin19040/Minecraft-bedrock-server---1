#!/bin/bash

echo "Starting Minecraft Bedrock server..."

chmod +x bedrock_server
./bedrock_server