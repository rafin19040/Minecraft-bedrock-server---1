#!/bin/bash

bash server.sh &
bash playit.sh